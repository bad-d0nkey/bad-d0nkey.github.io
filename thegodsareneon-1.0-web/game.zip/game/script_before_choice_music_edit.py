# This is a variable that is True if you've declared whatever instead of in-deed, and False
# otherwise.
default whatever = False


# The game starts here.
label start:

    # Start by playing some music.
    play music "seenitcoming.mp3"

    scene bg street1
    with fade

    "Pay attention."

    "Listen up!"

    "Take your stance."
 
    "In-deed!"

    scene bg street2
    with fade

    "Arms oustretched!"

    "Wide out and back." 
    
    "Kss! Kss!"

    scene bg street3
    with fade
    
    "What is right is always right."

    "Yes, what is right is {b}always{/b} right!"

    menu:

        "{b}in-deed{/b}":

            jump indeed1

        "{b}{i}whatever{/i}{/b}":

            jump whatever1


label indeed1:

    scene bg street4
    with fade

    "Stay true." 

    "Stay true to yourself, my son!"

    scene bg street5
    with fade
    
    "You have raised my concerns." 

    "So listen up!"    

    menu:

        "{b}in-deed{/b}":

            jump indeed2

        "{b}{i}whatever{/i}{/b}":
        
            jump whatever2


label indeed2:

    scene bg fence
    with fade

    "What is this problem that you carry?"

    "For how long have you carried it?"    

    "Say to it:" 

    "No. No longer."    

    scene bg apartment
    with fade
    
    "Son, it may be difficult for you."

    "And, son, it may seem to be unyielding,"

    "although long you reflect upon it."

    scene bg computer
    with fade
    
    "The answer to the problem" 

    "is here inside {b}you{/b}."

    "In-deed, in-deed, in-deed!"
 
stop music fadeout 1.0

play music "ticktock.mp3"

scene bg dissolving

"Upload virus?"

menu:

    "{b}yes{/b}":

        jump freedom

    "{b}no{/b}":

        jump shhhh   

label freedom:

    scene bg freedom
    with fade

    "{b}Freedom.{/b}"

    scene bg phonelock
    with fade

    "{b}And the neon gods are no longer.{/b}"

    stop music

    return

label shhhh:

    scene bg shhhh
    with fade

    "{b}Shhhh.......{/b}"

    scene bg phonelock
    with fade

    "{b}And the neon gods remain.{/b}"

    stop music

    return

label whatever2:

    $ whatever = True

    scene bg phonelock
    with fade

    "{b}And the neon gods remain.{/b}"

    stop music

    return

label whatever1:

    $ whatever = True

    scene bg phonelock
    with fade

    "{b}And the neon gods remain.{/b}"

    stop music

    return
