# This is a variable that is True if you've declared whatever instead of in-deed, and False
# otherwise.
default whatever = False


# The game starts here.
label start:

    # Start by playing some music.
    play music "seenitcoming.mp3"

    scene bg street1
    with fade

    "Pay attention."

    "Listen up!"

    scene bg street2
    with fade
    "Take your stance."
 
    "In-deed! In-deed!"

    scene bg street3
    with fade

    "Arms oustretched!"

    "Held out wide and back." 
    
    "Kss! Kss!"

    scene bg street4
    with fade
    
    "What is right is always right."

    "Yes, what is right is {b}always{/b} right!"

    menu:

        "{b}in-deed{/b}":

            jump indeed1

        "{b}{i}whatever{/i}{/b}":

            jump whatever1


label indeed1:

    scene bg street5
    with fade

    "Steady now." 

    "Stay true, my son!"

    scene bg street6
    with fade
    
    "You have raised my concerns." 

    "So listen up!"    

    menu:

        "{b}in-deed{/b}":

            jump indeed2

        "{b}{i}whatever{/i}{/b}":
        
            jump whatever2


label indeed2:

    scene bg street7
    with fade

    "What is this problem that you carry?"

    "For how long have you carried it?"    

    scene bg fence
    with fade

    "Say to it:" 

    "No! No longer."    

    scene bg apartment
    with fade
    
    "Son, it may be difficult for you."

    "And, son, it may seem to be unyielding."

    scene bg frontdoor
    with fade

    "Long you reflect upon it."

    "Indeed. Indeed."

    scene bg computer
    with fade
    
    "The answer to the problem -" 

    "it's here inside {b}you{/b}."

    scene bg hackerfacing
    with fade

    "The answer lies within."

    "In-deed, in-deed, in-deed!"
 
stop music fadeout 2.0

queue music "ticktock.mp3"

scene bg dissolving 
with fade

"Upload virus?"

menu:

    "{b}yes{/b}":

        jump freedom

    "{b}no{/b}":

        jump shhhh   

label freedom:

    stop music 

    play music "splashmusic.mp3"

    scene bg freedom 
    with fade

    "{b}Freedom.{/b}"

    scene bg nomore
    with fade

    "{b}And the neon gods are no longer.{/b}"

    stop music

    return

label shhhh:

    stop music

    play music "tension.mp3"

    scene bg shhhh
    with fade

    "{b}Shhhh.......{/b}"

    scene bg phonelock
    with fade

    "{b}And the neon gods remain.{/b}"

    stop music

    return

label whatever2:

    $ whatever = True

    stop music

    play music "tension.mp3"

    scene bg phonelock
    with fade

    "{b}And the neon gods remain.{/b}"

    stop music

    return

label whatever1:

    $ whatever = True

    stop music

    play music "tension.mp3"

    scene bg phonelock
    with fade

    "{b}And the neon gods remain.{/b}"

    stop music

    return
